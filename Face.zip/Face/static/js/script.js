document.getElementById("uploadForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);

  const statusBox = document.getElementById("statusBox");
  statusBox.innerHTML = "🔍 Recognizing...";

  const response = await fetch("/upload", {
    method: "POST",
    body: formData,
  });

  const result = await response.json();

  if (result.success) {
    statusBox.innerHTML = `✅ Welcome, ${result.name}! Door Unlocked.`;
    statusBox.style.backgroundColor = "#d1f7c4";
  } else {
    statusBox.innerHTML = "❌ Face not recognized. Access Denied.";
    statusBox.style.backgroundColor = "#ffe5e5";
  }
});
